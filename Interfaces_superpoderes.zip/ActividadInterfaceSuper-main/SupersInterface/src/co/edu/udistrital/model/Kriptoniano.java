package co.edu.udistrital.model;

public class Kriptoniano extends SuperHeroe implements Volar, Fuerza, SuperVelocidad{

	@Override
	public String velocidadMaxima(double velocidad) {
		return "El kriptoniano corre maximo a " + velocidad + " kilometros por hora";
	}

	@Override
	public String arrancar(double cordX) {
		return "Empieza a correr desde la coordenada (" + cordX + ")";
	}

	@Override
	public String velocidadActual(double velocidad) {
		return "El kriptoniano corre a " + velocidad + " kilometros por hora";
	}

	@Override
	public String fuerzaMaxima(double fuerza) {
		return "El kriptoniano alcanza una fuerza de " + fuerza + " kilogramos por metros cuadrados cuadrados";
	}

	@Override
	public String lanzar(double cordX, double cordY) {
		return "El kriptoniano lanza el objeto hasta las coordenadas (" + cordX + ", " + cordY+ ")";
	}

	@Override
	public String fuerzaActual(double fuerza) {
		return "El kriptoniano golpea con una fuerza de " + fuerza + " kilogramos por metros cuadrados";
	}

	@Override
	public String resistencia(double porcentaje) {
		return "El kriptoniano tiene una resistencia del " + porcentaje + " % a los ataques";
	}

	@Override
	public String despegar(double cordX, double cordY) {
		return "El kriptoniano despega desde las coordenadas (" + cordX + ", " + cordY + ")";
	}

	@Override
	public String detenerse(double cordX, double cordY) {
		return "El kriptoniano se detiene en las coordenadas (" + cordX + ", " + cordY + ")";
	}

	@Override
	public String levitar(double cordY) {
		return "El kriptoniano levita hasta la coordenada (" + cordY + ")";
	}

	@Override
	public String controlAereo(double cordX, double cordY) {
		return  "Kriptoniano volando a las coordenadas (" + cordX + ", " + cordY + ")";
	}


}
