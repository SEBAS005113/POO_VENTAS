package co.edu.udistrital.model;

public class Alienigena extends SuperHeroe implements Volar, Fuerza, SuperVelocidad, Nadar{

	@Override
	public String aguantarRespiracion(double tiempo) {
		return "El alienigena aguanta la respiración por " + tiempo + " segundos";
	}

	@Override
	public String bucear(double cordX, double cordY) {
		return "El alienigena bucea hasta las coordenadas (" + cordX + ", " + cordY + ")";
	}

	@Override
	public String velocidad(double velocidad) {
		return "El alienigena nada a " + velocidad + " kilometros por hora";
	}

	@Override
	public String velocidadMaxima(double velocidad) {
		return "El alienigena puede correr a una velocidad de " + velocidad + " kilometros por hora";
	}

	@Override
	public String arrancar(double cordX) {
		return "El alienigena comienza a correr desde la coordenada (" + cordX + ")";
	}

	@Override
	public String velocidadActual(double velocidad) {
		return "El alienigena está corriendo a una velocidad de " + velocidad + " kilometros por hora";
	}

	@Override
	public String fuerzaMaxima(double fuerza) {
		return "El alienigena alcanza una fuerza de " + fuerza + " kilogramos por centimetros cuadrados";
	}

	@Override
	public String lanzar(double cordX, double cordY) {
		return "El alienigena lanza el objeto hasta las coordenadas (" + cordX + ", " + cordY+ ")";		
	}

	@Override
	public String fuerzaActual(double fuerza) {
		return "El alienigena golpea con una fuerza de " + fuerza + " kilogramos por centimetros cuadrados";
	}

	@Override
	public String resistencia(double porcentaje) {
		return "El alienigena tiene una resistencia del " + porcentaje + " % a los ataques";
	}

	@Override
	public String despegar(double cordX, double cordY) {
		return "El alienigena despega desde las coordenadas (" + cordX + ", " + cordY + ")";
	}

	@Override
	public String detenerse(double cordX, double cordY) {
		return "El alienigena se detiene en las coordenadas (" + cordX + ", " + cordY + ")";
	}

	@Override
	public String levitar(double cordY) {
		return "El alienigena levita hasta la coordenada (" + cordY + ")";
	}

	@Override
	public String controlAereo(double cordX, double cordY) {
		return  "Alienígena volando a las coordenadas (" + cordX + ", " + cordY + ")";
	}


}
