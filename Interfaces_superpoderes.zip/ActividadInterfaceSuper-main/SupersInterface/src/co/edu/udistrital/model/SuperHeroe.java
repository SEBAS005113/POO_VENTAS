package co.edu.udistrital.model;

public abstract class SuperHeroe {
	private String nombre;
	private double cordX, cordY;
	
}
