package co.edu.udistrital.model;

public class Velocista extends SuperHeroe implements SuperVelocidad{

	@Override
	public String velocidadMaxima(double velocidad) {
		return "El velocista puede correr a una velocidad de " + velocidad + "kilometros por segundo";
	}

	@Override
	public String arrancar(double cordX) {
		return "El velocista comienza a correr desde la coordenada (" + cordX + ")";
	}

	@Override
	public String detenerse(double cordX, double cordY) {
		return "El velocista se detiene en las coordenadas (" + cordX + ", " + cordY + ")";
	}

	@Override
	public String velocidadActual(double velocidad) {
		return "El velocista está corriendo a una velocidad de " + velocidad + " kilometros por segundo";
	}

	@Override
	public String resistencia(double porcentaje) {
		return "El velocista tiene una resistencia del " + porcentaje + " % a los ataques";
	}

}
