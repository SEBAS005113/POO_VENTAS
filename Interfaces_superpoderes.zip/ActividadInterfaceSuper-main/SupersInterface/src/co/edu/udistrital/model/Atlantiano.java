package co.edu.udistrital.model;

public class Atlantiano extends SuperHeroe implements Nadar, Fuerza{

	@Override
	public String fuerzaMaxima(double fuerza) {
		return "El atlantiano alcanza una fuerza de " + fuerza + " toneladas por metros cuadrados";
	}

	@Override
	public String lanzar(double cordX, double cordY) {
		return "El atlantiano lanza el objeto hasta las coordenadas (" + cordX + "," + cordY+ ")";		
	}

	@Override
	public String fuerzaActual(double velocidad) {
		return "El atlantiano golpea con una fuerza de ";
	}

	@Override
	public String aguantarRespiracion(double tiempo) {
		return "El atlantiano aguanta la respiración por " + tiempo + " segundos";
	}

	@Override
	public String bucear(double cordX, double cordY) {
		return "El atlantiano bucea hasta las coordenadas (" + cordX + ", " + cordY + ")";
	}

	@Override
	public String resistencia(double porcentaje) {
		return "El atlantiano tiene una resistencia del " + porcentaje +" % a los ataques";
	}

	@Override
	public String velocidad(double velocidad) {
		return "El atlantiano nada a " + velocidad + " kilometros por hora";
	}


}
