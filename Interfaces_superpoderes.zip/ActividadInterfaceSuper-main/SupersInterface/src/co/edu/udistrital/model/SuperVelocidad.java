package co.edu.udistrital.model;

public interface SuperVelocidad {
	String velocidadMaxima(double velocidad);
	String arrancar(double cordX);
	String detenerse(double cordX, double cordY);
	String velocidadActual(double velocidad);
	String resistencia(double porcentaje);
	
	
}
