package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;
	public Controller() {
		vista = new VistaConsola();
		funcionar();
	}
	
	public void funcionar() {

	}
}