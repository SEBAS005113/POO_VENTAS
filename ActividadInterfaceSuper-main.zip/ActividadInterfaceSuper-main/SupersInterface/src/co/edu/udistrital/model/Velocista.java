package co.edu.udistrital.model;

public class Velocista extends SuperHeroe implements SuperVelocidad{

	@Override
	public String velocidadMaxima(double velocidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String arrancar(double cordX) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String detenerse(double cordX, double cordY) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String velocidadAcutal(double velocidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String resistencia(double porcentaje) {
		// TODO Auto-generated method stub
		return null;
	}

}
