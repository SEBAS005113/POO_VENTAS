package co.edu.udistrital.model;

public class Atlantiano extends SuperHeroe implements Nadar, Fuerza{

	@Override
	public String fuerzaMaxima(double velocidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String lanzar(double cordX, double cordY) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String fuerzaAcutal(double velocidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String aguantarRespiracion(double tiempo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String bucear(double cordX, double cordY) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String resistencia(double porcentaje) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String velocidad(double velocidad) {
		// TODO Auto-generated method stub
		return null;
	}


}
