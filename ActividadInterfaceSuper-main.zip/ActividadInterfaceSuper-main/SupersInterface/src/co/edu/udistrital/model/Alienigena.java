package co.edu.udistrital.model;

public class Alienigena extends SuperHeroe implements Volar, Fuerza, SuperVelocidad, Nadar{

	@Override
	public String aguantarRespiracion(double tiempo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String bucear(double cordX, double cordY) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String velocidad(double velocidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String velocidadMaxima(double velocidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String arrancar(double cordX) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String velocidadAcutal(double velocidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String fuerzaMaxima(double velocidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String lanzar(double cordX, double cordY) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String fuerzaAcutal(double velocidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String resistencia(double porcentaje) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String despegar(double cordX, double cordY) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String detenerse(double cordX, double cordY) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String levitar(double cordY) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String controlAereo(double cordX, double cordY) {
		// TODO Auto-generated method stub
		return null;
	}


}
