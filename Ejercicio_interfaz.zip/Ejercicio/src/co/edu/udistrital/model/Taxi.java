package co.edu.udistrital.model;

public class Taxi implements Vehiculo {

	@Override
	public String arrancar() {
		return "Arrancar para hacer servicio";
	}

	@Override
	public String detener() {
		return "Parar para preguntar a donde no voy a ir";
	}

}
