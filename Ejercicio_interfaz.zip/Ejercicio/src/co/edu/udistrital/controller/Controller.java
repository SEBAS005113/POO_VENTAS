package co.edu.udistrital.controller;
import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;
public class Controller {
	private VistaConsola vista;
	private Sitp vehiculo_hermoso;
	private Bicicleta caballo_de_acero;
	private Taxi veterano;
	
	public Controller() {
		vista = new VistaConsola();
		vehiculo_hermoso = new Sitp();
		caballo_de_acero = new Bicicleta();
		veterano = new Taxi();
		funcionar();
	}
	public void funcionar() {
		vista.mostrarInformacion(vehiculo_hermoso.arrancar());
		vista.mostrarInformacion(vehiculo_hermoso.detener());
		vista.mostrarInformacion(vehiculo_hermoso.echarPito());
		vista.mostrarInformacion("________________________________________");
		vista.mostrarInformacion(caballo_de_acero.arrancar());
		vista.mostrarInformacion(caballo_de_acero.detener());
		vista.mostrarInformacion(caballo_de_acero.echarPito());
		vista.mostrarInformacion("________________________________________");
		vista.mostrarInformacion(veterano.arrancar());
		vista.mostrarInformacion(veterano.detener());
		vista.mostrarInformacion(veterano.echarPito());
	}
}
